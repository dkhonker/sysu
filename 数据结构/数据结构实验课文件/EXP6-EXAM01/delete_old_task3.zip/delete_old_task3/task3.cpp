#include <stdio.h>
#include <stdlib.h>

int m;  //������ 

struct node{
	int data;
	struct node *next;
};
node *head; // headָ��ͷ�ڵ�  ֻ���壬δ����ռ� 

void insert(int i, int x){//����x��a[i] 
	node *p = head;
	while (i >= 1){
		p = p->next; i--;
	} 
	node *q = (node*) malloc(sizeof(node));
	q->data = x; q->next = p->next; p->next = q;	
} 


void reverse(){
	node* cur=head->next;
	if(cur==NULL){
		return;
	}
	node* cn=cur->next;
	cur->next=NULL;
	while(cn!=NULL){
		node* cnn=cn->next;
		cn->next=cur;
		cur=cn;
		cn=cnn;
	}
	head->next=cur;
}

void printlinkedlist(){
	node* cur=head->next;
	while(cur!=NULL){
		printf("%d ",cur->data);
		cur=cur->next;
	}
}

int main() {
	scanf("%d", &m);
	head = (node*) malloc(sizeof(node));
	head->next = NULL;
	for (int i = 0; i < m; i++){
		int x;
		scanf("%d", &x); 
		insert(i, x); 
	}
	reverse();
	printlinkedlist();
	return 0;
}

