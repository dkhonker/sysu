//
// Created by Wsin on 2021/03/18.
//
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/time.h>
char inputfilename[12] = "0.in";
char outputfilename[12] = "0.out";
FILE * fin;
FILE * fout;
struct node{
	int data;
	struct node *next;
};
node *head; // headָ��ͷ�ڵ�  ֻ���壬δ����ռ� 

void insert(int i, int x){//����x��a[i] 
	node *p = head;
	while (i >= 1){
		p = p->next; i--;
	} 
	node *q = (node*) malloc(sizeof(node));
	q->data = x; q->next = p->next; p->next = q;	
} 

void deleteByIndex(int i){ //ɾ��a[i] 
	node *p = head;
	node *q = head->next;
	while (i > 1){
		p = q; q = p->next; i--;
	}
	p->next = q->next;
	free(q);
} 


void find(int x){//���ҵ�һ��x 
	node *p = head->next; 
	int j = 1;
	while (p != NULL && p->data != x){
		p = p->next; j++;
	}
	if (p == NULL) j = 0;
	printf("%d\n", j);
}

void count(int x, int y){//ͳ��[x,y]��Ԫ�ظ���	
	int k = 0;
	node *p = head->next; 
	while (p != NULL){
		if (p->data >= x && p->data <= y) k++;
		p = p->next;
	}
	printf("%d\n", k);
}

void deleteByRange(int x, int y){ //ȥ��[x,y]��Χ�ڵ�Ԫ�� 
	node *p = head;
	node *q = head-> next;
	while (q != NULL){
		if (q->data >= x && q->data <= y){
			p->next = q->next; free(q); q = p->next;
		}
		else{
			p = q; q = p->next;
		}
	}
} 

void eliminateRepeat(){ //ȥ���ظ�Ԫ�� 
	node *r = head->next, *p, *q;
	while (r != NULL){
		p = r; q = r->next;
		while (q != NULL){
			if (q->data == r->data){
				p->next = q->next; free(q);	q = p->next;
			}
			else{
				p = q; q = p->next;
			}
		}
		r = r->next;
	}
}

void reverse(){
	node* cur=head->next;
	if(cur==NULL){
		return;
	}
	node* cn=cur->next;
	cur->next=NULL;
	while(cn!=NULL){
		node* cnn=cn->next;
		cn->next=cur;
		cur=cn;
		cn=cnn;
	}
	head->next=cur;
}

void finprintlinkedlist(char* inputfilename,int k){
	fin = fopen(inputfilename, "w");
	fprintf(fin,"%d\n",k);
	node* cur=head->next;
	while(cur!=NULL){
		fprintf(fin,"%d\n",cur->data);
		cur=cur->next;
	}
	fclose(fin);
}
void foutprintlinkedlist (char* outputfilename){
	fout = fopen(outputfilename, "w");
	node* cur=head->next;
	while(cur!=NULL){
		fprintf(fout,"%d\n",cur->data);
		cur=cur->next;
	}
	fclose(fout);
}
int main(int argc, char* argv[]) {
    int x=0;
    int k=0;
    for (int i = 0; i < 10; i++) {
    	inputfilename[0] = '0' + i;
        outputfilename[0] = '0' + i;
    	scanf("%d",&k);
    	head = (node*) malloc(sizeof(node));
		head->next = NULL;
		for(int j=0;j<k;j++){
			x=(rand() % (30000-0));
			insert(j, x); 
		} 
		finprintlinkedlist(inputfilename,k);
		reverse();
		foutprintlinkedlist(outputfilename);
    }
    return 0;
}

